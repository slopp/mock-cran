require("methods", character = TRUE, quietly = TRUE)
