/* Definition for BLAS functions */
#define TAUCS_BLAS_UNDERSCORE
/* Does the compiler support C99 complex numbers? */
#undef TAUCS_C99_COMPLEX
