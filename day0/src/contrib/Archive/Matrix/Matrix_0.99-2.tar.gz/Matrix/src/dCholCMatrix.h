#ifndef MATRIX_DCHOLCMATRIX_H
#define MATRIX_DCHOLCMATRIX_H

#include "dtCMatrix.h"

SEXP dCholCMatrix_validate(SEXP object);

#endif
