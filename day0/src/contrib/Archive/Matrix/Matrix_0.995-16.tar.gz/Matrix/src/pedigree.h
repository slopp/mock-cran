#ifndef MATRIX_PEDIGREE_H
#define MATRIX_PEDIGREE_H

#include "Mutils.h"
#include "dtCMatrix.h"

SEXP pedigree_chol(SEXP x, SEXP ans);

#endif
