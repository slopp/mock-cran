#ifndef MATRIX_SSCCHOL_H
#define MATRIX_SSCCHOL_H

#include "tscMatrix.h"

SEXP sscChol_validate(SEXP object);

#endif
