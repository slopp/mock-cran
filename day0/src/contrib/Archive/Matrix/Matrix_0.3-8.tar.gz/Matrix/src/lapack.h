// -*- c++ -*-
//      LAPACK++ (V. 1.1)
//      (C) 1992-1996 All Rights Reserved.
//
//  Modifications Copyright (C) 2000-2000 the R Development Core Team

#ifndef _LAPACK_H_
#define _LAPACK_H_

#include "lapackd.h"
//#include "lapackc.h"

#endif 
// _LAPACK_H_
