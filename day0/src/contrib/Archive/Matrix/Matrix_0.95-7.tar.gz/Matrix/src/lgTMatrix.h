#ifndef MATRIX_LGTMATRIX_H
#define MATRIX_LCTMATRIX_H

#include <Rdefines.h>
#include "Mutils.h"
#include "triplet_to_col.h"

SEXP lgTMatrix_validate(SEXP x);

#endif
