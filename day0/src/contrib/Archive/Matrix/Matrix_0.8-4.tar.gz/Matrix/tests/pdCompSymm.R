library(Matrix)
showClass('pdCompSymm')
