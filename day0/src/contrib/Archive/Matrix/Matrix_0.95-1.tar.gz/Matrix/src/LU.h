#ifndef MATRIX_LU_H
#define MATRIX_LU_H
#include "dtrMatrix.h"

SEXP LU_expand(SEXP x);

#endif
