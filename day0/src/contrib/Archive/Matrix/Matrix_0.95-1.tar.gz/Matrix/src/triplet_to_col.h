void triplet_to_col(int n_row, int n_col, int nz,
		    const int Ti[], const int Tj[], const double Tx[],
		    int Ap[], int Ai[], double Ax[]);
