#ifndef MATRIX_BBCROSSTAB_H
#define MATRIX_BBCROSSTAB_H

#include "Mutils.h"

extern void ssc_metis_order(int n, const int Tp [], const int Ti [],
			    int Perm[], int iPerm[]);
#endif
