union <- function(x, y) unique(c(x, y))
isMatrix <- function(x) length(dim(x)) == 2
