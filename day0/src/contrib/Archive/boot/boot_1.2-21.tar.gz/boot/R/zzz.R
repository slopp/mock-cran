isMatrix <- function(x) length(dim(x)) == 2
