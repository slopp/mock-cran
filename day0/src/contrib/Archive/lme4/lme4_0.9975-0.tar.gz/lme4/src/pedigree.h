#ifndef MATRIX_PEDIGREE_H
#define MATRIX_PEDIGREE_H

#include "Syms.h"
#include <Rdefines.h>

SEXP pedigree_chol(SEXP x, SEXP ans);

#endif
