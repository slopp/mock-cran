.onUnload <- function(libpath)
    library.dynam.unload("lme4", libpath)
