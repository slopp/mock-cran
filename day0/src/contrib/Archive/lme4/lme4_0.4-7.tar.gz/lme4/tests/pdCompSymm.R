library(lme4)
showClass('pdCompSymm')
