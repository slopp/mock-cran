#ifndef LME4_WISHART_H
#define LME4_WISHART_H

#include "lme4_utils.h"

SEXP lme4_rWishart(SEXP ns, SEXP df, SEXP scal);

#endif /* LME4_WISHART_H */
