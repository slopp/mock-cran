#ifndef _@PKG@_RCPP_HELLO_WORLD_H
#define _@PKG@_RCPP_HELLO_WORLD_H

#include <Rcpp.h>

RcppExport SEXP rcpp_hello_world() ;

#endif
