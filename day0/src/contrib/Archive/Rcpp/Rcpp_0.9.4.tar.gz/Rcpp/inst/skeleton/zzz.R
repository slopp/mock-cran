
.onLoad <- function(pkgname, libname){
    loadRcppModules()
}

