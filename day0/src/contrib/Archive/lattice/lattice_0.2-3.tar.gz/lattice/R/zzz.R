### loading required library grid
library(grid)
trellis.device(new = F)
