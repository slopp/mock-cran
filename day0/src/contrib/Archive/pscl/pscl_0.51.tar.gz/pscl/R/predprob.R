"predprob" <-
function(obj, ...){
    UseMethod("predprob")
}

