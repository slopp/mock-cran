# Cook's Distance (J. Fox)

# last modified 27 Mar 03 by J. Fox

cookd <- function(model, ...) cooks.distance(model, ...)
