
rcppeigen_hello_world <- function(){
	.Call( "rcppeigen_hello_world", PACKAGE = "@PKG@" )
}

