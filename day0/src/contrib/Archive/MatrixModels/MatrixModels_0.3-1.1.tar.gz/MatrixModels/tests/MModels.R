### So I see things in old saved  "R CMD check .." directories
require("Matrix")
require("MatrixModels")
sessionInfo()
packageDescription("Matrix")
