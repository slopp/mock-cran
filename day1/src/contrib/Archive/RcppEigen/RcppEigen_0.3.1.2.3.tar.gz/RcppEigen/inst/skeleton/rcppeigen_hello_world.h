#ifndef _@PKG@_RCPP_HELLO_WORLD_H
#define _@PKG@_RCPP_HELLO_WORLD_H

#include <RcppEigen.h>

RcppExport SEXP rcppeigen_hello_world() ;

#endif
