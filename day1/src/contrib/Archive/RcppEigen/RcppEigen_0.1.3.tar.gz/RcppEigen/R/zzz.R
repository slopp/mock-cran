## .onLoad <- function(libname, pkgname) {
##     require(methods, quietly=TRUE)
##     loadRcppModules()
## }
