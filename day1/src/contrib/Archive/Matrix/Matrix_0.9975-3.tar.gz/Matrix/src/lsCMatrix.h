#ifndef MATRIX_LSCMATRIX_H
#define MATRIX_LSCMATRIX_H

#include "Mutils.h"

SEXP lsCMatrix_validate(SEXP x);

#endif
