#include "Mutils.h"

SEXP Tsparse_validate(SEXP x);
SEXP Tsparse_to_Csparse(SEXP x);

