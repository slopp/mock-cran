#ifndef MATRIX_LGTMATRIX_H
#define MATRIX_LCTMATRIX_H

#include "Mutils.h"

SEXP lgTMatrix_validate(SEXP x);

#endif
