#include "sscChol.h"

SEXP sscChol_validate(SEXP object)
{
    return ScalarLogical(1);
}

