#include "dCholCMatrix.h"

SEXP dCholCMatrix_validate(SEXP object)
{
    return ScalarLogical(1);
}

