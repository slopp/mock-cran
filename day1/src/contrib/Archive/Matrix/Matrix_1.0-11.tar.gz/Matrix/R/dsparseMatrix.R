### d(ouble)sparseMatrix methods :

setMethod("image", "dsparseMatrix",
	  function(x, ...) image(as(x, "dgTMatrix"), ...))

setMethod("chol", signature(x = "dsparseMatrix"),
	   function(x, pivot=FALSE, ...) {
	       px <- as(x, "symmetricMatrix")
	       if (isTRUE(validObject(px, test=TRUE)))
		   chol(as(px, "CsparseMatrix"), pivot=pivot, ...)
	       else stop("'x' is not positive definite -- chol() undefined.")
	   })

setMethod("determinant", signature(x = "dsparseMatrix", logarithm = "logical"),
          function(x, logarithm = TRUE, ...)
          determinant(as(x,"CsparseMatrix"), logarithm, ...))
##-> now dgC or dsC or dtC .. which *have* their methods

setMethod("lu", signature(x = "dsparseMatrix"), # "FIXME": do in C, so can cache 'x@factors$LU'
	  function(x, ...) lu(as(x, "dgCMatrix"), ...))


setMethod("is.finite", signature(x = "dsparseMatrix"),
	  function(x) {
	      if(any(!is.finite(x@x))) {
                  r <- allTrueMat(x, packed = FALSE)
                  x <- as(as(as(x,"CsparseMatrix"), "dgCMatrix"),"dgTMatrix")
		  notF <- which(!is.finite(x@x))
		  r[cbind(x@i[notF], x@j[notF]) + 1L] <- FALSE
                  r
	      }
              else allTrueMat(x)
	  })
setMethod("is.infinite", signature(x = "dsparseMatrix"),
	  function(x) {
	      if(any((isInf <- is.infinite(x@x)))) {
		  cld <- getClassDef(class(x))
		  if(extends(cld, "triangularMatrix") && x@diag == "U")
		      isInf <- is.infinite((x <- .diagU2N(x, cld))@x)
		  r <- as(x, "lMatrix") # will be "lsparseMatrix" - *has* x slot
		  r@x <- if(length(isInf) == length(r@x)) isInf else is.infinite(r@x)
		  if(!extends(cld, "CsparseMatrix"))
		      r <- as(r, "CsparseMatrix")
		  as(.Call(Csparse_drop, r, 0), "nMatrix") # a 'pattern matrix
	      }
	      else is.na_nsp(x)
	  })

## Group Methods, see ?Arith (e.g.): "Ops" --> ./Ops.R
## -----
## others moved to ./Csparse.R (and 'up' to ./sparseMatrix.R):
##  "Math2" is in ./dMatrix.R


