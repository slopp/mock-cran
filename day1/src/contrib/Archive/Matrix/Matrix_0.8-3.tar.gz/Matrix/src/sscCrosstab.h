#ifndef MATRIX_SSCCROSSTAB_H
#define MATRIX_SSCCROSSTAB_H

#include "Mutils.h"

SEXP sscCrosstab(SEXP flist, SEXP upper);

#endif
