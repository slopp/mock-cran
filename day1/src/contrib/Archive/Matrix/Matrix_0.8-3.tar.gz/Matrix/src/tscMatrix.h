#ifndef MATRIX_TSC_H
#define MATRIX_TSC_H

#include "Mutils.h"

SEXP tsc_validate(SEXP x);
SEXP tsc_transpose(SEXP x);

#endif
