#ifndef MATRIX_LTCMATRIX_H
#define MATRIX_LTCMATRIX_H

#include "Mutils.h"

SEXP ltCMatrix_validate(SEXP x);
SEXP ltCMatrix_trans(SEXP x);

#endif
