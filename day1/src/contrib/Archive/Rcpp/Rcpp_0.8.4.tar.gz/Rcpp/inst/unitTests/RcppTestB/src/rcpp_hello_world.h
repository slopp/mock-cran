#ifndef _RcppTestB_RCPP_HELLO_WORLD_H
#define _RcppTestB_RCPP_HELLO_WORLD_H

#include <Rcpp.h>

RcppExport SEXP rcpp_hello_world() ;
RcppExport SEXP hello_world_ex() ;

#endif
