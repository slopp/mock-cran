#!/usr/bin/r -t

## Section 5.10.1 of 'Writing R Extensions' has a simple .Call example
## for convolution which we are rewriting here


