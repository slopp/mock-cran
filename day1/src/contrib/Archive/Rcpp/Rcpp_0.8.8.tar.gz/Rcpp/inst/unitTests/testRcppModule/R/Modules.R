
## create modules (their pointers will be initialized when first used)
yada <- Module("yada")
stdVector <- Module("stdVector")
NumEx <- Module("NumEx")

