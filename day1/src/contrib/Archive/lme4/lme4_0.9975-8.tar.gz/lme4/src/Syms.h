#include <Rdefines.h>
#include <Rconfig.h>

#ifdef HAVE_VISIBILITY_ATTRIBUTE
# define attribute_hidden __attribute__ ((visibility ("hidden")))
#else
# define attribute_hidden
#endif

SEXP attribute_hidden
    lme4_DSym,
    lme4_DimSym,
    lme4_DimNamesSym,
    lme4_GpSym,
    lme4_LSym,
    lme4_OmegaSym,
    lme4_RXXSym,
    lme4_RZXSym,
    lme4_RZXinvSym,
    lme4_XSym,
    lme4_XtXSym,
    lme4_XtySym,
    lme4_ZZpOSym,
    lme4_ZtSym,
    lme4_ZtXSym,
    lme4_ZtZSym,
    lme4_ZtySym,
    lme4_bVarSym,
    lme4_cnamesSym,
    lme4_devCompSym,
    lme4_devianceSym,
    lme4_diagSym,
    lme4_factorSym,
    lme4_fixefSym,
    lme4_flistSym,
    lme4_gradCompSym,
    lme4_iSym,
    lme4_ncSym,
    lme4_pSym,
    lme4_permSym,
    lme4_rXySym,
    lme4_rZySym,
    lme4_ranefSym,
    lme4_statusSym,
    lme4_uploSym,
    lme4_wrkresSym,
    lme4_wtsSym,
    lme4_xSym,
    lme4_ySym;



