#ifndef MATRIX_PEDIGREE_H
#define MATRIX_PEDIGREE_H

#include "lme4_utils.h"
#include <Rdefines.h>

SEXP pedigree_chol(SEXP x, SEXP ans);

#endif
