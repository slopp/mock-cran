library(lme4)
# data(guPrenat)
# system.time(fm <-
#             GLMM(ifelse(prenat == 'Modern', 1, 0) ~ childAge +
#                        motherAge + indig + momEd +
#                        husEd + husEmpl + toilet + pcInd81 + ssDist,
#                        data = as(guPrenat, "data.frame"), family = binomial,
#                        random = list(mom = ~ 1, cluster = ~1),
#                        verbose = TRUE))
# summary(fm)
q("no")

