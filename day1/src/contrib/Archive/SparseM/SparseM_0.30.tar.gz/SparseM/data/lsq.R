lsq <- read.matrix.hb(system.file("HBdata","lsq.rra",package="SparseM"))
