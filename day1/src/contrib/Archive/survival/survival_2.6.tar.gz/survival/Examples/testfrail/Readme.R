Run 
	R --no-save <Rtest >Rtest.out
	diff Rtest.out Rtest.out.save

to check all the examples.

If the default R random number generator changes there will be one line of
difference.

