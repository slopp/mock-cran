### loading required library grid
autoload("loess.smooth", "modreg")
autoload("loess", "modreg")
require(grid)
trellis.device(new = F)
