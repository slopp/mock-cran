### loading required library grid



## Need global variable to handle more in print.trellis
.lattice.print.more <- FALSE

autoload("loess.smooth", "modreg")
autoload("loess", "modreg")
require(grid)
