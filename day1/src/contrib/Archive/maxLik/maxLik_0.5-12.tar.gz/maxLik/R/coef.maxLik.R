coef.maxLik <- function( object, ... ) {
   return( object$estimate )
}
