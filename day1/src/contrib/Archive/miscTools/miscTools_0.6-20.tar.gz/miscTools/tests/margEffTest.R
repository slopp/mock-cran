library( "miscTools" )

try( margEff( 123 ) )

